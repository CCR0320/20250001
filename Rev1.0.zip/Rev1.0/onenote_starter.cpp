/*
  OneNote Launcher
  - OneNoteのタスクがあれば終了してから指定ファイルを開く
  - config.ini に指定ファイルを記載
  Author: mizuki miyahara
*/

#include <iostream>
#include <fstream>
#include <string>
#include <filesystem>
#include <windows.h>

namespace fs = std::filesystem;

void logMessage(const std::string& message, const fs::path& baseDir) {
    std::ofstream log(baseDir / "onenote_starter.log", std::ios::app);
    SYSTEMTIME st; GetLocalTime(&st);
    char buffer[128];
    sprintf_s(buffer, "[%04d-%02d-%02d %02d:%02d:%02d] ",
        st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
    log << buffer << message << std::endl;
}

bool isOneNoteRunning() {
    FILE* pipe = _popen("tasklist /FI \"IMAGENAME eq ONENOTE.EXE\"", "r");
    if (!pipe) return false;
    char buffer[256]; bool found = false;
    while (fgets(buffer, sizeof(buffer), pipe))
        if (strstr(buffer, "ONENOTE.EXE")) { found = true; break; }
    _pclose(pipe);
    return found;
}

void killOneNote(const fs::path& dir) {
    if (!isOneNoteRunning()) {
        logMessage("ONENOTE.EXE not running. Skipped termination.", dir);
        return;
    }
    system("taskkill /F /IM ONENOTE.EXE >nul 2>&1");
    logMessage("Terminated ONENOTE.EXE", dir);
}

std::string readConfig(const fs::path& cfgPath, const fs::path& dir) {
    std::ifstream cfg(cfgPath);
    if (!cfg.is_open()) {
        std::ofstream newCfg(cfgPath);
        newCfg << "[OneNote]\nfile = sample.one\n";
        newCfg.close();
        logMessage("Generated default config.ini", dir);
        std::cout << "config.ini を生成しました。file = sample.one を修正してください。\n";
        exit(0);
    }
    std::string line;
    while (std::getline(cfg, line)) {
        if (line.find("file") != std::string::npos) {
            size_t eq = line.find('=');
            if (eq != std::string::npos) {
                std::string value = line.substr(eq + 1);
                value.erase(0, value.find_first_not_of(" \t"));
                value.erase(value.find_last_not_of(" \t\r\n") + 1);
                return value;
            }
        }
    }
    logMessage("file entry not found in config.ini", dir);
    exit(1);
}

void launchFile(const std::string& filePath, const fs::path& dir) {
    fs::path target = filePath;
    if (!fs::exists(target)) target = dir / filePath;
    if (!fs::exists(target)) {
        logMessage("File not found: " + target.string(), dir);
        std::cerr << "指定ファイルが存在しません: " << target << std::endl;
        exit(1);
    }
    ShellExecuteA(nullptr, "open", target.string().c_str(), nullptr, nullptr, SW_SHOWNORMAL);
    logMessage("Launched " + target.string(), dir);
}

int main() {
    fs::path baseDir = fs::absolute(fs::path("."));
    fs::path cfg = baseDir / "config.ini";
    killOneNote(baseDir);
    Sleep(1000);
    std::string file = readConfig(cfg, baseDir);
    launchFile(file, baseDir);
    logMessage("Process completed.", baseDir);
    return 0;
}
